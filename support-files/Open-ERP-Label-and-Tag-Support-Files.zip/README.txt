Open ERP label and tag support files

P-touch Editor layouts for Brother QL-800 with 62 mm continuous tape:
- OPENERP=PACKING.lbx: packing labels, about 62 x 61 mm.
- OPENERP=MATERIAL.lbx: material certificate labels, 62 x 88 mm.

3D-printable trade size 3 tag models (3.75 x 1.875 in):
- TRADE SIZE 3 TAG.step
- TRADE SIZE 3 TAG DOUBLE HOLE.step

Open ERP saves labels as PNG images. Open the matching LBX layout in
P-touch Editor and place the generated PNG on it before printing.
Print a test label to confirm fit and printer settings.
